function App() {
  // ...
  return (
    <div>
      <h1>amigodocs.com: Document Assistance Network</h1>
      {/* ... */}
    </div>
  );
}