# amigodocs.com

A collaborative network for helping people obtain essential government documents (birth certificates, passports, visas, etc.) in Central and South America.

## Features

- Secure, encrypted file sharing
- Helper verification and trust badges
- Two-factor authentication
- Privacy controls
- GDPR/LGPD compliance
- Smart matching algorithm
- And more!